//
//  NetworkManager.m
//  TravelGuide
//
//  Created by pradeep on 25/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import "GENetworkManager.h"



@interface GENetworkManager()<NSURLSessionDelegate>

@end


/*
   Network Manager - Connect to API backend to get Train, Bus & Flight data from server to be persisited
 */
@implementation GENetworkManager


/*
 getAllFlights - Get all flights from backend API
 */
+(void)getAllFlights:(GEFlightDataCollectedCallback)callback{
    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:nil delegateQueue:nil];
    NSURL *url = [NSURL URLWithString:@"https://api.myjson.com/bins/w60i"];
    
    //GMSLog(@"SERVER: RE BAckend collect to visit ID URL = %@",url);
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    

    request.timeoutInterval = 20;

    
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    request.HTTPMethod = @"GET";
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSUInteger statusCode =  [(NSHTTPURLResponse *)response statusCode];
         NSLog(@"Status Code = %ld",statusCode);
          NSLog(@"Response  = %@",response);
          callback(data,&error);

    }];
    
    [postDataTask resume];

}



/*
 getAllTrains - Get all Trains from backend API
 */
+(void)getAllTrains:(GETrainDataCollectedCallback)callback{
    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:nil delegateQueue:nil];
    NSURL *url = [NSURL URLWithString:@"https://api.myjson.com/bins/3zmcy"];
    
    //GMSLog(@"SERVER: RE BAckend collect to visit ID URL = %@",url);
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    
    request.timeoutInterval = 20;
    
    
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    request.HTTPMethod = @"GET";
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSUInteger statusCode =  [(NSHTTPURLResponse *)response statusCode];
        NSLog(@"Status Code = %ld",statusCode);
        NSLog(@"Response  = %@",response);
             callback(data,&error);
        
    }];
    
    [postDataTask resume];
}


/*
 getAllBuses - Get all Buses from backend API
 */
+(void)getAllBuses:(GEBusDataCollectedCallback)callback{
    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:sessionConfiguration delegate:nil delegateQueue:nil];
    NSURL *url = [NSURL URLWithString:@"https://api.myjson.com/bins/37yzm"];
    
    //GMSLog(@"SERVER: RE BAckend collect to visit ID URL = %@",url);
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    
    request.timeoutInterval = 20;
    
    
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    request.HTTPMethod = @"GET";
    
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSUInteger statusCode =  [(NSHTTPURLResponse *)response statusCode];
        NSLog(@"Status Code = %ld",statusCode);
        NSLog(@"Response  = %@",response);
            callback(data,&error);
        
    }];
    
    [postDataTask resume];

}




#pragma mark - URL Session Deleagtes methods for NSURLSession for HTTPS connection
/*!
 * @discussion delegate: trust the credential for the session task
 * @param none
 * @return void
 */
//- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *credential))completionHandler
//{
//    if(completionHandler != NULL){
//        completionHandler(NSURLSessionAuthChallengeUseCredential, [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust]);
//    }
//}
//
//
//
///*!
// * @discussion delegate: authenticate the domain for secure connection
// Debug mode compare if Host address matches domain address in
// Info.plist for ATS to test self-signed certificate connections.
// 
// Domain names will be part of Info.plist ATS section
// * @param none
// * @return void
// */
//- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completionHandler{
//    if(completionHandler != NULL){
//        if([GREUtils checkDomainNameExistsATS:challenge.protectionSpace.host]){
//            NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
//            
//            completionHandler(NSURLSessionAuthChallengeUseCredential,credential);
//        }
//        else{
//            NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
//            completionHandler(NSURLSessionAuthChallengeUseCredential,credential);
//        }
//    }
//}


@end
