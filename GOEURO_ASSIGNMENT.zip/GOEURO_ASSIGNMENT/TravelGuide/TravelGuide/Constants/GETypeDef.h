//
//  GETypeDef.h
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#ifndef GETypeDef_h
#define GETypeDef_h


#endif /* GETypeDef_h */
