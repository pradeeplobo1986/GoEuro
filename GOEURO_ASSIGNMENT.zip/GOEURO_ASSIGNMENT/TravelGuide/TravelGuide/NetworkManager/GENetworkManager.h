//
//  NetworkManager.h
//  TravelGuide
//
//  Created by pradeep on 25/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

@import Foundation;




typedef void (^GETrainDataCollectedCallback)(NSData *jsonData,NSError **error);

typedef void (^GEBusDataCollectedCallback)(NSData *jsonData,NSError **error);

typedef void (^GEFlightDataCollectedCallback)(NSData *jsonData,NSError **error);


@interface GENetworkManager : NSObject




/*
 getAllFlights - Get all flights from backend API
 */
+(void)getAllFlights:(GEFlightDataCollectedCallback)callback;


/*
 getAllTrains - Get all Trains from backend API
 */
+(void)getAllTrains:(GETrainDataCollectedCallback)callback;


/*
 getAllBuses - Get all Buses from backend API
 */
+(void)getAllBuses:(GEBusDataCollectedCallback)callback;


@end
