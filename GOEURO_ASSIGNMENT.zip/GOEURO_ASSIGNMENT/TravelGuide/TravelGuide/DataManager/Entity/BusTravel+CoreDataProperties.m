//
//  BusTravel+CoreDataProperties.m
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "BusTravel+CoreDataProperties.h"

@implementation BusTravel (CoreDataProperties)

+ (NSFetchRequest<BusTravel *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"BusTravel"];
}

@dynamic arrival_time;
@dynamic departure_time;
@dynamic id;
@dynamic number_of_stops;
@dynamic price_in_euros;
@dynamic provider_logo;

@end
