

Release Notes:


Features Supported:

1)Getting all Travel Data for Train, Bus & Flight and caching in offline mode using Core data

2) Support for Offline mode




Features To be done:

1) Sorting travel data by Depature time , Arrival time & Ticket prices to be implemnted



Known Issues:

1) Code not optimized to compare previous ID and update accordingly

2) App crahses sometimes due to callback from GEAppmanager

3) UI is not optimized on iPad




Tested Devices:

Tested on Simulator for iPhone & iPad
