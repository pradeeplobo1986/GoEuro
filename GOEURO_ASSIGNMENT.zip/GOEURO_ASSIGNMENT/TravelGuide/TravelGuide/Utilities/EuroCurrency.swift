//
//  EuroCurrency.swift
//  TravelGuide
//
//  Created by pradeep on 27/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

import Foundation

@objc class CurrencyFormatter:NSObject {
    
    /// Formats the receiver as a currency string using the specified three digit currencyCode. Currency codes are based on the ISO 4217 standard.
    class func formatAsCurrency(currencyValue: NSNumber) -> String? {
       
        let currencyFormatter = NumberFormatter()
        currencyFormatter.numberStyle = NumberFormatter.Style.currency
        currencyFormatter.currencyCode = "EUR"
//        currencyFormatter.maximumFractionDigits = floor(currencyValue.doubleValue) == currencyValue.doubleValue ? 0 : 2
        let number = currencyValue;
        return currencyFormatter.string(from:number)
    }
}
