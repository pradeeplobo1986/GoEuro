//
//  GEJSONParser.h
//  TravelGuide
//
//  Created by pradeep on 25/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GEJSONParser : NSObject

@end
