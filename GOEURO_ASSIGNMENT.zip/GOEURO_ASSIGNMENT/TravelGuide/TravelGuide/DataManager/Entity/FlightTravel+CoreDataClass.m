//
//  FlightTravel+CoreDataClass.m
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "FlightTravel+CoreDataClass.h"

@implementation FlightTravel

@end
