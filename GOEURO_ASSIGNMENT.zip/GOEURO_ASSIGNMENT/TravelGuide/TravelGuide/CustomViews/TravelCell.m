//
//  TableCell.m
//  TravelGuide
//
//  Created by pradeep on 25/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import "TravelCell.h"

@implementation TravelCell
//
//- (void)awakeFromNib {
//    [super awakeFromNib];
//    // Initialization code
//}
//
//- (id) initWithCoder:(NSCoder *)aDecoder {
//    if (self = [super initWithCoder:aDecoder]) {
//    
//    }
//    
//    return self;
//}
//
//
//
//- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
//    [super setSelected:selected animated:animated];
//
//    // Configure the view for the selected state
//}

@end
