//
//  GEAppManager.m
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import "GEAppManager.h"
#import "GEConstants.h"
#import "GENetworkManager.h"
#import "GEDataManager.h"
#import "Reachability.h"

@interface GEAppManager()
   @property(atomic,strong)NSDictionary *travelDict;
@end
/*
 GEAppManager - Starts prefetching of Train, Bus, flight data using Network Manager
                 JSON data is passed to DataManager tp be persisited to Core Data for offline storage
                 Final Data array is shared to AppManager to be used for UI display
 */
@implementation GEAppManager



/**
 *  Get AppManager instance.
 *
 *  @return AppManager Singleton object
 *
 *  @discussion The method returns the Singleton Object of GEAppManager.
 *
 */
+ (instancetype)sharedManager{
    static GEAppManager *sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
        
        
    });
    return sharedInstance;
    
}




/**
 *  Get All Travel Data using Network Manager if internet is presetn
 *   Else Try to get Offline data from Core Data
 *  @discussion The method returns the  Travel Data collected either from Netwrok Manager or DataManager.
 *
 */
-(void)insertAllTravelData:(GETravelDataCollectedCallback)callback{
    self.managedObjectContext = [[GEDataManager sharedManager] managedObjectContext];
  
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        NSLog(@"There IS NO internet connection");
        // block3
        NSLog(@"Completed all insertion");
        NSMutableDictionary *lTravelDict = [@{} mutableCopy];
        NSArray *flightTravelArray = [[GEDataManager sharedManager] getAllFlightTravelData];
        if(flightTravelArray != nil){
            lTravelDict[GE_FLIGHT_KEY] = flightTravelArray;
        }
        
        NSArray *trainTravelArray = [[GEDataManager sharedManager] getAllTrainTravelData];
        if(trainTravelArray != nil){
            lTravelDict[GE_TRAIN_KEY] = trainTravelArray;
        }
        
        NSArray *busTravelArray = [[GEDataManager sharedManager] getAllBusTravelData];
        if(busTravelArray != nil){
            lTravelDict[GE_BUS_KEY] = busTravelArray;
        }
        
        NSDictionary *dictionary = [NSDictionary dictionaryWithDictionary:lTravelDict];
        self.travelDict = dictionary;
        callback(dictionary);
        
    } else {
        NSLog(@"There IS internet connection");
        
        __weak GEAppManager *weakSelf = self;
        
        dispatch_group_t group = dispatch_group_create();
        
        dispatch_group_async(group,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^ {
            [GENetworkManager getAllBuses:^(NSData *jsonData, NSError *__autoreleasing *error) {
                NSDictionary *respDict = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:error];
                //NSLog(@"Response  = %@",respDict);
                [weakSelf saveBusDataToCoreData:respDict];
            }];
        });
        
        
        dispatch_group_async(group,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^ {
            [GENetworkManager getAllTrains:^(NSData *jsonData, NSError *__autoreleasing *error) {
                NSDictionary *respDict = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:error];
                //NSLog(@"Response  = %@",respDict);
                [weakSelf saveTrainDataToCoreData:respDict];
            }];
        });
        
        dispatch_group_async(group,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^ {
            [GENetworkManager getAllFlights:^(NSData *jsonData, NSError *__autoreleasing *error) {
                NSDictionary *respDict = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:error];
                //NSLog(@"Response  = %@",respDict);
                [weakSelf saveFlightDataToCoreData:respDict];
            }];
        });
        
        dispatch_group_notify(group,dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^ {
            // block3
            NSLog(@"Completed all insertion");
            NSMutableDictionary *lTravelDict = [@{} mutableCopy];
            NSArray *flightTravelArray = [[GEDataManager sharedManager] getAllFlightTravelData];
            if(flightTravelArray != nil){
                lTravelDict[GE_FLIGHT_KEY] = flightTravelArray;
            }
            
            NSArray *trainTravelArray = [[GEDataManager sharedManager] getAllTrainTravelData];
            if(trainTravelArray != nil){
                lTravelDict[GE_TRAIN_KEY] = trainTravelArray;
            }
            
            NSArray *busTravelArray = [[GEDataManager sharedManager] getAllBusTravelData];
            if(busTravelArray != nil){
                lTravelDict[GE_BUS_KEY] = busTravelArray;
            }
            
            NSDictionary *dictionary = [NSDictionary dictionaryWithDictionary:lTravelDict];
            self.travelDict = dictionary;
            callback(dictionary);
        });
    }
    
}




-(void)saveTrainDataToCoreData:(NSDictionary *)jsonDict{
        [[GEDataManager sharedManager] addTrainTravelData:jsonDict];
}


-(void)saveFlightDataToCoreData:(NSDictionary *)jsonDict{
    [[GEDataManager sharedManager] addFlightTravelData:jsonDict];
}


-(void)saveBusDataToCoreData:(NSDictionary *)jsonDict{
    [[GEDataManager sharedManager] addBusTravelData:jsonDict];
}




-(void)debugCoreDataValues:(NSArray *)travelArray{

    if(travelArray != nil){
        [travelArray enumerateObjectsUsingBlock:^(TrainTravel *trainTravel, NSUInteger idx, BOOL * _Nonnull stop){
               NSLog(@"---TrainTravel Details");
              NSLog(@"Train arrival Time = %f",trainTravel.arrival_time);
              NSLog(@"Train departure Time = %f",trainTravel.departure_time);
              NSLog(@"Train ID = %hd",trainTravel.id);
              NSLog(@"Train Number of stops = %hd",trainTravel.number_of_stops);
              NSLog(@"Train Ticket Cost = %f",trainTravel.price_in_euros);
              NSLog(@"Train Logo = %@",trainTravel.provider_logo);
            
        }];
    }
}


@end
