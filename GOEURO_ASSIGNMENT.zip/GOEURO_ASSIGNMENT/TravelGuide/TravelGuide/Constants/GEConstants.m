//
//  GEConstants.m
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import "GEConstants.h"

//JSON
 NSString* const  GE_JSONKEY_ARRIVAL_TIME = @"arrival_time";
 NSString* const  GE_JSONKEY_DEPARTURE_TIME = @"departure_time";
 NSString* const  GE_JSONKEY_ID = @"id";
 NSString* const  GE_JSONKEY_NUMBER_OF_STOPS = @"number_of_stops";
 NSString* const  GE_JSONKEY_PRICE_IN_EUROS = @"price_in_euros";
 NSString* const  GE_JSONKEY_PROVIDER_LOGO = @"provider_logo";

//Size Key of Image
NSString* const  GE_PROVIDER_LOGO_SIZETEXT = @"{size}";
NSString* const  GE_PROVIDER_LOGO_SIZE_REPLACETEXT = @"63";


//Keys for TravelDict
NSString* const  GE_TRAIN_KEY = @"TRAIN";
NSString* const  GE_BUS_KEY = @"BUS";
NSString* const  GE_FLIGHT_KEY = @"FLIGHT";;
