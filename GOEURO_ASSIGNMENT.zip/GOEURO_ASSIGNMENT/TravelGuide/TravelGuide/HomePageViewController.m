//
//  ViewController.m
//  TravelGuide
//
//  Created by pradeep on 24/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import "HomePageViewController.h"
#import "GEAppManager.h"
#import <CoreData/CoreData.h>
#import "GEConstants.h"
#import "TravelGuide-Swift.h"
#import "TravelGuide+CoreDataModel.h"
#import "TravelCell.h"
#import "Haneke.h"



NSUInteger const  TRAINMODE= 1;
NSUInteger const BUSMODE = 2;
NSUInteger const FLIGHTMODE = 3;


@interface HomePageViewController ()<NSFetchedResultsControllerDelegate,UITableViewDataSource,UITableViewDelegate>
    @property (weak, nonatomic) IBOutlet UITableView *tableView;
     @property (nonatomic, strong) NSFetchedResultsController *fetchedResultsController;
     @property (nonatomic, strong) NSDictionary *travelDictionary;
    @property (nonatomic, assign) NSUInteger modeType;
@end

@implementation HomePageViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.modeType  = 1;
    
//    UINib *cellNib = [UINib nibWithNibName:@"TravelCell" bundle:nil];
//    [self.tableView registerNib:cellNib forCellReuseIdentifier:@"TravelCellIdentifier"];
    
    __weak HomePageViewController *weakSelf = self;
    [[GEAppManager sharedManager] insertAllTravelData:^(NSDictionary *travelDict) {
        self.travelDictionary = travelDict;
        //[weakSelf initializeFetchedResultsController];
        [[NSOperationQueue mainQueue] addOperationWithBlock:^{
             [weakSelf.tableView reloadData];
        }];
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}






#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.modeType == BUSMODE){
        return [self.travelDictionary[GE_BUS_KEY] count];
    }
    else if(self.modeType == TRAINMODE){
        return [self.travelDictionary[GE_TRAIN_KEY] count];
    }
    else{
        return [self.travelDictionary[GE_FLIGHT_KEY] count];
    }
    
}



static NSString *cellIdentifier = @"TravelCellIdentifier";
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   TravelCell *cell = (TravelCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(self.modeType == BUSMODE){
         NSArray *busArray = self.travelDictionary[GE_BUS_KEY];
        BusTravel *busTravel = (BusTravel *) busArray[indexPath.row];
        
        if(busTravel != nil){
            double duration = fabs(busTravel.arrival_time  - busTravel.departure_time);
            cell.lblDuration.text = [NSString stringWithFormat:@"Direct %0.2lfh",duration];
            

            cell.lblPrice.text =  [CurrencyFormatter formatAsCurrencyWithCurrencyValue:[NSNumber numberWithDouble:busTravel.price_in_euros]];
            
            
            if(busTravel.number_of_stops > 0){
                      cell.lblArrivalTime.text = [NSString stringWithFormat:@"%.2lf - %.2lf(+%hd)",busTravel.departure_time, busTravel.arrival_time,busTravel.number_of_stops];
            }
            else{
                      cell.lblArrivalTime.text = [NSString stringWithFormat:@"%.2lf - %.2lf",busTravel.departure_time, busTravel.arrival_time];
            }
      
            
            if(busTravel.provider_logo.length > 0){
                        [cell.imgViewLogo hnk_setImageFromURL:[NSURL URLWithString:busTravel.provider_logo]];
            }
            else{
                   cell.imgViewLogo.image = [UIImage imageNamed:@"DefaultImage"];
            }
            
         
        }
    }
    else if(self.modeType == TRAINMODE){
        NSArray *trainArray = self.travelDictionary[GE_TRAIN_KEY];
        TrainTravel *trainTravel = (TrainTravel *) trainArray[indexPath.row];
        
        if(trainTravel != nil){
            double duration = fabs(trainTravel.arrival_time - trainTravel.departure_time);
            cell.lblDuration.text = [NSString stringWithFormat:@"Direct %0.2lfh",duration];
            
            cell.lblPrice.text =  [CurrencyFormatter formatAsCurrencyWithCurrencyValue:[NSNumber numberWithDouble:trainTravel.price_in_euros]];
            
            if(trainTravel.number_of_stops > 0){
                cell.lblArrivalTime.text = [NSString stringWithFormat:@"%.2lf - %.2lf(+%hd)",trainTravel.departure_time, trainTravel.arrival_time,trainTravel.number_of_stops];
            }
            else{
                cell.lblArrivalTime.text = [NSString stringWithFormat:@"%.2lf - %.2lf",trainTravel.departure_time, trainTravel.arrival_time];
            }
            
            if(trainTravel.provider_logo.length > 0){
                [cell.imgViewLogo hnk_setImageFromURL:[NSURL URLWithString:trainTravel.provider_logo]];
            }
            else{
                cell.imgViewLogo.image = [UIImage imageNamed:@"DefaultImage"];
            }
          
        }
    }
    else{
         NSArray *flightArray = self.travelDictionary[GE_FLIGHT_KEY];
        FlightTravel *flightTravel = (FlightTravel *) flightArray[indexPath.row];
        
        if(flightTravel != nil){
            double duration = fabs(flightTravel.departure_time - flightTravel.arrival_time);
            cell.lblDuration.text = [NSString stringWithFormat:@"DIrect %0.2lfh",duration];
            
            cell.lblPrice.text =  [CurrencyFormatter formatAsCurrencyWithCurrencyValue:[NSNumber numberWithDouble:flightTravel.price_in_euros]];
            
            
            if(flightTravel.number_of_stops > 0){
                cell.lblArrivalTime.text = [NSString stringWithFormat:@"%.2lf - %.2lf(+%hd)",flightTravel.departure_time, flightTravel.arrival_time,flightTravel.number_of_stops];
            }
            else{
                       cell.lblArrivalTime.text = [NSString stringWithFormat:@"%.2lf - %.2lf",flightTravel.departure_time, flightTravel.arrival_time];
            }
            
            if(flightTravel.provider_logo.length > 0){
                    [cell.imgViewLogo hnk_setImageFromURL:[NSURL URLWithString:flightTravel.provider_logo]];
            }
            else{
                cell.imgViewLogo.image = [UIImage imageNamed:@"DefaultImage"];
            }
        }
    }
    return cell;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 130.0;
}


#pragma mark - Cell Selected Index

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Offer coming soon" message:@"Offer details are not yet implemented!" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        
    }];
    
    [alertController addAction:okAction];
    
    [self presentViewController:alertController animated:YES completion:^{
    }];
}

#pragma mark - Fetch Results Controller
- (void)initializeFetchedResultsController
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"BusTravel"];
    
    NSSortDescriptor *idSort = [NSSortDescriptor sortDescriptorWithKey:@"id" ascending:YES];
    
    [request setSortDescriptors:@[idSort]];
    
    NSManagedObjectContext *moc = [[GEAppManager sharedManager] managedObjectContext]; //Retrieve the main queue NSManagedObjectContext
    
    [self setFetchedResultsController:[[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:moc sectionNameKeyPath:nil cacheName:nil]];
    [[self fetchedResultsController] setDelegate:self];
    
    NSError *error = nil;
    if (![[self fetchedResultsController] performFetch:&error]) {
        NSLog(@"Failed to initialize FetchedResultsController: %@\n%@", [error localizedDescription], [error userInfo]);
        abort();
    }
}


#pragma mark - NSFetchedResultsControllerDelegate
- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller
{
    [self.tableView beginUpdates];
}



- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type
{
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.tableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeDelete:
            [self.tableView  deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeMove:
        case NSFetchedResultsChangeUpdate:
            break;
    }
}
- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(NSIndexPath *)newIndexPath
{
    switch(type) {
        case NSFetchedResultsChangeInsert:
            [self.tableView  insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeDelete:
            [self.tableView  deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
        case NSFetchedResultsChangeUpdate:
          //  [self configureCell:[self.tableView  cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
            break;
        case NSFetchedResultsChangeMove:
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [self.tableView  insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            break;
    }
}
- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
    [self.tableView  endUpdates];
}




-(void)testLogic{
   
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW,0), ^{
            NSLog(@"1");
            
            dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW,0), ^{
                 NSLog(@"2");
            });
            
            dispatch_sync(dispatch_get_main_queue(), ^{
                NSLog(@"3");
            });
            
            dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW,0), ^{
                NSLog(@"4");
            });
            
            NSLog(@"5");
        });
}



#pragma mark - Sort All TableView WITH MODE

- (IBAction)sortTravelData:(id)sender {
}

#pragma mark - RELOAD TABLEVIEWS WITH MODE
- (IBAction)trainModeSelected:(id)sender {
    self.modeType = TRAINMODE;
    [self.tableView reloadData];
}



- (IBAction)busModeSelected:(id)sender {
      self.modeType = BUSMODE;
        [self.tableView reloadData];
}

- (IBAction)flightModeSelected:(id)sender {
       self.modeType = FLIGHTMODE;
        [self.tableView reloadData];
}






@end
