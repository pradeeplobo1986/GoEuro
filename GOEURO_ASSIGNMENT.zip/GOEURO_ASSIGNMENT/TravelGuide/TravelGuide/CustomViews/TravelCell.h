//
//  TableCell.h
//  TravelGuide
//
//  Created by pradeep on 25/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TravelCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgViewLogo;

@property (weak, nonatomic) IBOutlet UILabel *lblArrivalTime;
@property (weak, nonatomic) IBOutlet UILabel *lblPrice;
@property (weak, nonatomic) IBOutlet UILabel *lblDuration;

@end
