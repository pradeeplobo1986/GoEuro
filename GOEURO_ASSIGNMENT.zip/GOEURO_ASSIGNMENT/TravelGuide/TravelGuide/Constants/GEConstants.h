//
//  GEConstants.h
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import <Foundation/Foundation.h>

@import Foundation;

//JSON
extern NSString* const  GE_JSONKEY_ARRIVAL_TIME;
extern NSString* const  GE_JSONKEY_DEPARTURE_TIME;
extern NSString* const  GE_JSONKEY_ID;
extern NSString* const  GE_JSONKEY_NUMBER_OF_STOPS;
extern NSString* const  GE_JSONKEY_PRICE_IN_EUROS;
extern NSString* const  GE_JSONKEY_PROVIDER_LOGO;

//Size Key of Image
extern NSString* const  GE_PROVIDER_LOGO_SIZETEXT;
extern NSString* const  GE_PROVIDER_LOGO_SIZE_REPLACETEXT;


//Keys for TravelDict
extern NSString* const  GE_TRAIN_KEY;
extern NSString* const  GE_BUS_KEY;
extern NSString* const  GE_FLIGHT_KEY;
