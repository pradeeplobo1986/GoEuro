//
//  GEDataManager.m
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import "GEDataManager.h"
#import "TravelGuide+CoreDataModel.h"
#import "GEConstants.h"

@interface GEDataManager()
- (void)initializeCoreData;
@end

/*
 GEDataManager - Will cache bus, train, flight data for offline mode
 Return Sorted bus, train, flight by departure time
 */
@implementation GEDataManager





/**
 *  Get AppManager instance.
 *
 *  @return AppManager Singleton object
 *
 *  @discussion The method returns the Singleton Object of GEAppManager.
 *
 */
+ (instancetype)sharedManager{
    static GEDataManager *sharedInstance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
          [sharedInstance initializeCoreData];
    });
    return sharedInstance;
    
}




#pragma mark - Core Data stack

@synthesize persistentContainer = _persistentContainer;


- (void)initializeCoreData
{
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"TravelGuide" withExtension:@"momd"];
    NSManagedObjectModel *mom = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    NSAssert(mom != nil, @"Error initializing Managed Object Model");
    
    NSPersistentStoreCoordinator *psc = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:mom];
    NSManagedObjectContext *moc = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    [moc setPersistentStoreCoordinator:psc];
    [self setManagedObjectContext:moc];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *documentsURL = [[fileManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
    NSURL *storeURL = [documentsURL URLByAppendingPathComponent:@"TravelGuide.sqlite"];
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void) {
        NSError *error = nil;
        NSPersistentStoreCoordinator *psc = [[self managedObjectContext] persistentStoreCoordinator];
        NSPersistentStore *store = [psc addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error];
        NSAssert(store != nil, @"Error initializing PSC: %@\n%@", [error localizedDescription], [error userInfo]);
    });
}



- (NSPersistentContainer *)persistentContainer {
    // The persistent container for the application. This implementation creates and returns a container, having loaded the store for the application to it.
    @synchronized (self) {
        if (_persistentContainer == nil) {
            _persistentContainer = [[NSPersistentContainer alloc] initWithName:@"TravelGuide"];
            [_persistentContainer loadPersistentStoresWithCompletionHandler:^(NSPersistentStoreDescription *storeDescription, NSError *error) {
                if (error != nil) {
                    // Replace this implementation with code to handle the error appropriately.
                    // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                    
                    /*
                     Typical reasons for an error here include:
                     * The parent directory does not exist, cannot be created, or disallows writing.
                     * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                     * The device is out of space.
                     * The store could not be migrated to the current model version.
                     Check the error message to determine what the actual problem was.
                     */
                    NSLog(@"Unresolved error %@, %@", error, error.userInfo);
                    abort();
                }
            }];
        }
    }
    
    return _persistentContainer;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *context = self.persistentContainer.viewContext;
    NSError *error = nil;
    if ([context hasChanges] && ![context save:&error]) {
        // Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, error.userInfo);
        abort();
    }
}




#pragma mark - Delete All Old Data from Core Data Stack
- (void)deleteAllObjectsInCoreData
{
}





#pragma mark - Adding Data to Core Data
//Thread safe to add to core data
-(void)addTrainTravelData:(NSDictionary *)jsonDict{
    @synchronized (self) {
        NSString *arrivalTimeString = @"";
        NSNumber *arrivalTime = @(0);
        
        NSString *departureTimeString = @"";
        NSNumber *departureTime = @(0);
        
        NSString *idString = @"";
        NSNumber *idNumber = @(0);
        
        NSString *noOfStopsString = @"";
        NSNumber *numberOfStops = @(0);
        
        NSString *priceInEuroString = @"";
        NSNumber *priceInEuros = @(0);
        
        NSString *providerLogo = @"";
        
        
        if(jsonDict != nil){
            for (NSDictionary *travelDict in jsonDict) {
                NSLog(@"---Flight Travel Data = %@",travelDict);
                
                //Insert here
                TrainTravel* trainTravel = [NSEntityDescription insertNewObjectForEntityForName:@"TrainTravel" inManagedObjectContext:self.managedObjectContext];
                
                arrivalTimeString = travelDict[GE_JSONKEY_ARRIVAL_TIME];
                if(arrivalTimeString != nil){
                    arrivalTime = @([arrivalTimeString doubleValue]);
                    trainTravel.arrival_time = [arrivalTime doubleValue];
                    
                }
                
                departureTimeString = travelDict[GE_JSONKEY_DEPARTURE_TIME];
                if(departureTimeString != nil){
                    departureTime = @([departureTimeString doubleValue]);
                    trainTravel.departure_time = [departureTime doubleValue];
                }
                
                
                
                idString = travelDict[GE_JSONKEY_ID];
                if(idString != nil){
                    idNumber = @([idString integerValue]);
                    trainTravel.id = [idNumber integerValue];
                }
                
                
                noOfStopsString = travelDict[GE_JSONKEY_NUMBER_OF_STOPS];
                if(noOfStopsString != nil){
                    numberOfStops = @([noOfStopsString integerValue]);
                    trainTravel.number_of_stops = [numberOfStops integerValue];
                }
                
                
                
                priceInEuroString = travelDict[GE_JSONKEY_PRICE_IN_EUROS];
                if(priceInEuroString != nil){
                    priceInEuros = @([priceInEuroString integerValue]);
                    trainTravel.price_in_euros = [priceInEuros integerValue];
                }
                
                providerLogo = travelDict[GE_JSONKEY_PROVIDER_LOGO];
                if(providerLogo !=nil){
                    providerLogo = [providerLogo stringByReplacingOccurrencesOfString: GE_PROVIDER_LOGO_SIZETEXT
                                                                           withString:GE_PROVIDER_LOGO_SIZE_REPLACETEXT];
                    trainTravel.provider_logo = providerLogo;
                }
                
                
                
                
            }
            
            NSError *error = nil;
            if ([self.managedObjectContext save:&error] == NO) {
                NSLog(@"Error saving context: %@\n%@", [error localizedDescription], [error userInfo]);
            }
            
        }

    }
}



//Thread safe to add to core data
-(void)addBusTravelData:(NSDictionary *)jsonDict{
        @synchronized (self) {
            NSString *arrivalTimeString = @"";
            NSNumber *arrivalTime = @(0);
            
            NSString *departureTimeString = @"";
            NSNumber *departureTime = @(0);
            
            NSString *idString = @"";
            NSNumber *idNumber = @(0);
            
            NSString *noOfStopsString = @"";
            NSNumber *numberOfStops = @(0);
            
            NSString *priceInEuroString = @"";
            NSNumber *priceInEuros = @(0);
            
            NSString *providerLogo = @"";
            
            
            if(jsonDict != nil){
                for (NSDictionary *travelDict in jsonDict) {
                    NSLog(@"---Flight Travel Data = %@",travelDict);
                    
                    //Insert here
                    BusTravel *busTravel = [NSEntityDescription insertNewObjectForEntityForName:@"BusTravel" inManagedObjectContext:self.managedObjectContext];
                    
                    arrivalTimeString = travelDict[GE_JSONKEY_ARRIVAL_TIME];
                    if(arrivalTimeString != nil){
                        arrivalTime = @([arrivalTimeString doubleValue]);
                        busTravel.arrival_time = [arrivalTime doubleValue];
                        
                    }
                    
                    departureTimeString = travelDict[GE_JSONKEY_DEPARTURE_TIME];
                    if(departureTimeString != nil){
                        departureTime = @([departureTimeString doubleValue]);
                        busTravel.departure_time = [departureTime doubleValue];
                    }
                    
                    
                    
                    idString = travelDict[GE_JSONKEY_ID];
                    if(idString != nil){
                        idNumber = @([idString integerValue]);
                        busTravel.id = [idNumber integerValue];
                    }
                    
                    
                    noOfStopsString = travelDict[GE_JSONKEY_NUMBER_OF_STOPS];
                    if(noOfStopsString != nil){
                        numberOfStops = @([noOfStopsString integerValue]);
                        busTravel.number_of_stops = [numberOfStops integerValue];
                    }
                    
                    
                    
                    priceInEuroString = travelDict[GE_JSONKEY_PRICE_IN_EUROS];
                    if(priceInEuroString != nil){
                        priceInEuros = @([priceInEuroString integerValue]);
                        busTravel.price_in_euros = [priceInEuros integerValue];
                    }
                    
                    providerLogo = travelDict[GE_JSONKEY_PROVIDER_LOGO];
                    if(providerLogo !=nil){
                        providerLogo = [providerLogo stringByReplacingOccurrencesOfString: GE_PROVIDER_LOGO_SIZETEXT
                                                                               withString:GE_PROVIDER_LOGO_SIZE_REPLACETEXT];
                        busTravel.provider_logo = providerLogo;
                    }
                    
                    
                    
                    
                }
                
                NSError *error = nil;
                if ([self.managedObjectContext save:&error] == NO) {
                    NSLog(@"Error saving context: %@\n%@", [error localizedDescription], [error userInfo]);
                }
                
            }

        }
}




//Thread safe to add to core data
-(void)addFlightTravelData:(NSDictionary *)jsonDict{
    @synchronized (self) {
        NSString *arrivalTimeString = @"";
        NSNumber *arrivalTime = @(0);
        
        NSString *departureTimeString = @"";
        NSNumber *departureTime = @(0);
        
        NSString *idString = @"";
        NSNumber *idNumber = @(0);
        
        NSString *noOfStopsString = @"";
        NSNumber *numberOfStops = @(0);
        
        NSString *priceInEuroString = @"";
        NSNumber *priceInEuros = @(0);
        
        NSString *providerLogo = @"";
        
        
        if(jsonDict != nil){
            for (NSDictionary *travelDict in jsonDict) {
                NSLog(@"---Flight Travel Data = %@",travelDict);
                
                //Insert here
                FlightTravel* flightTravel = [NSEntityDescription insertNewObjectForEntityForName:@"FlightTravel" inManagedObjectContext:self.managedObjectContext];
                
                arrivalTimeString = travelDict[GE_JSONKEY_ARRIVAL_TIME];
                if(arrivalTimeString != nil){
                    arrivalTime = @([arrivalTimeString doubleValue]);
                    flightTravel.arrival_time = [arrivalTime doubleValue];
                    
                }
                
                departureTimeString = travelDict[GE_JSONKEY_DEPARTURE_TIME];
                if(departureTimeString != nil){
                    departureTime = @([departureTimeString doubleValue]);
                    flightTravel.departure_time = [departureTime doubleValue];
                }
                
                
                
                idString = travelDict[GE_JSONKEY_ID];
                if(idString != nil){
                    idNumber = @([idString integerValue]);
                    flightTravel.id = [idNumber integerValue];
                }
                
                
                noOfStopsString = travelDict[GE_JSONKEY_NUMBER_OF_STOPS];
                if(noOfStopsString != nil){
                    numberOfStops = @([noOfStopsString integerValue]);
                    flightTravel.number_of_stops = [numberOfStops integerValue];
                }
                
                
                
                priceInEuroString = travelDict[GE_JSONKEY_PRICE_IN_EUROS];
                if(priceInEuroString != nil){
                    priceInEuros = @([priceInEuroString integerValue]);
                    flightTravel.price_in_euros = [priceInEuros integerValue];
                }
                
                providerLogo = travelDict[GE_JSONKEY_PROVIDER_LOGO];
                if(providerLogo !=nil){
                    providerLogo = [providerLogo stringByReplacingOccurrencesOfString: GE_PROVIDER_LOGO_SIZETEXT
                                                                           withString:GE_PROVIDER_LOGO_SIZE_REPLACETEXT];
                    flightTravel.provider_logo = providerLogo;
                }
                
                
                
                
            }
            
            NSError *error = nil;
            if ([self.managedObjectContext save:&error] == NO) {
                NSLog(@"Error saving context: %@\n%@", [error localizedDescription], [error userInfo]);
            }
            
        }

    }
}




#pragma mark - Fetching Data from Core Data
-(NSArray *)getAllTrainTravelData{
    NSManagedObjectContext *moc = self.managedObjectContext;
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TrainTravel"];
    
    NSError *error = nil;
    NSArray *results = [moc executeFetchRequest:request error:&error];
    if (!results) {
        NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
        // abort();
        return nil;
    }
    return results;
}


-(NSArray *)getAllBusTravelData{
    NSManagedObjectContext *moc = self.managedObjectContext;
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"BusTravel"];
    
    NSError *error = nil;
    NSArray *results = [moc executeFetchRequest:request error:&error];
    if (!results) {
        NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
        // abort();
        return nil;
    }
     return results;
}


-(NSArray *)getAllFlightTravelData{
   NSManagedObjectContext *moc = self.managedObjectContext;
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"FlightTravel"];
    
    NSError *error = nil;
    NSArray *results = [moc executeFetchRequest:request error:&error];
    if (!results) {
        NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
        // abort();
         return nil;
    }
    
     return results;
}




#pragma mark - Fetching Data from Core Data with sorted departure time
-(NSArray *)getAllTrainTravelDataSortedByDepTime:(BOOL)isAscending{
    NSManagedObjectContext *moc = self.managedObjectContext;
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TrainTravel"];
    
    NSSortDescriptor *desc = [NSSortDescriptor sortDescriptorWithKey:@"" ascending:isAscending];
    [request setSortDescriptors:@[desc]];
    
    NSError *error = nil;
    NSArray *results = [moc executeFetchRequest:request error:&error];
    if (!results) {
        NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
        // abort();
        return nil;
    }
    return results;
}


-(NSArray *)getAllBusTravelDataSortedByDepTime:(BOOL)isAscending{
    NSManagedObjectContext *moc = self.managedObjectContext;
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"BusTravel"];
    
    NSError *error = nil;
    NSArray *results = [moc executeFetchRequest:request error:&error];
    if (!results) {
        NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
        // abort();
        return nil;
    }
    return results;
}


-(NSArray *)getAllFlightTravelDataSortedByDepTime:(BOOL)isAscending{
    NSManagedObjectContext *moc = self.managedObjectContext;
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"FlightTravel"];
    
    NSError *error = nil;
    NSArray *results = [moc executeFetchRequest:request error:&error];
    if (!results) {
        NSLog(@"Error fetching Employee objects: %@\n%@", [error localizedDescription], [error userInfo]);
        // abort();
        return nil;
    }
    
    return results;
}




@end

