//
//  GEAppManager.h
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "TravelGuide+CoreDataModel.h"

typedef void (^GETravelDataCollectedCallback)(NSDictionary *travelDict);

/*
 GEAppManager - Starts prefetching of Train, Bus, flight data using Network Manager
 JSON data is passed to DataManager tp be persisited to Core Data for offline storage
 Final Data array is shared to AppManager to be used for UI display
 */
@interface GEAppManager : NSObject

 @property (strong)NSManagedObjectContext *managedObjectContext;

/**
 *  Get AppManager instance.
 *
 *  @return AppManager Singleton object
 *
 *  @discussion The method returns the Singleton Object of GEAppManager.
 *
 */
+(instancetype)sharedManager;




/**
 *  Get All Travel Data using Network Manager if internet is presetn
 *   Else Try to get Offline data from Core Data
 *  @discussion The method returns the  Travel Data collected either from Netwrok Manager or DataManager.
 *
 */
-(void)insertAllTravelData:(GETravelDataCollectedCallback)callback;


@end
