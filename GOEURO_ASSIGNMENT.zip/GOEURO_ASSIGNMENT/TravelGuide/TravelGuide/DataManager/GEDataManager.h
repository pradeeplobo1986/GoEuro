//
//  GEDataManager.h
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

/*
 GEDataManager - Will cache bus, train, flight data for offline mode 
                 Return Sorted bus, train, flight by departure time
 */
@interface GEDataManager : NSObject



/**
 *  Get AppManager instance.
 *
 *  @return AppManager Singleton object
 *
 *  @discussion The method returns the Singleton Object of GEAppManager.
 *
 */
+(instancetype)sharedManager;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

@property (strong)NSManagedObjectContext *managedObjectContext;

-(void)deleteAllTravelData;


-(void)addTrainTravelData:(NSDictionary *)jsonDict;



-(void)addBusTravelData:(NSDictionary *)jsonDict;


-(void)addFlightTravelData:(NSDictionary *)jsonDict;



-(NSArray *)getAllTrainTravelData;


-(NSArray *)getAllBusTravelData;

-(NSArray *)getAllFlightTravelData;

@end
