//
//  BusTravel+CoreDataProperties.h
//  TravelGuide
//
//  Created by pradeep on 26/02/17.
//  Copyright © 2017 lobo. All rights reserved.
//  This file was automatically generated and should not be edited.
//

#import "BusTravel+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface BusTravel (CoreDataProperties)

+ (NSFetchRequest<BusTravel *> *)fetchRequest;

@property (nonatomic) double arrival_time;
@property (nonatomic) double departure_time;
@property (nonatomic) int16_t id;
@property (nonatomic) int16_t number_of_stops;
@property (nonatomic) double price_in_euros;
@property (nullable, nonatomic, copy) NSString *provider_logo;
@end

NS_ASSUME_NONNULL_END
